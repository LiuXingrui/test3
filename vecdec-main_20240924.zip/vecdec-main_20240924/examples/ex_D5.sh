p1=0.01
./src/vecdec debug=1 seed=7 steps=1000 lerr=1\
	     finH= ./examples/96.3.963.alist useP=$p1 \
	     ntot=1000000 nvec=100000 uW=2
