#
src/vecdec mode=3.28 fdem=examples/surf_d5.dem fout=big 
