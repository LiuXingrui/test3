import os



def modify_file_ignore_comments(original_file, new_file):
    # Read the original file
    with open(original_file, 'r') as f:
        lines = f.readlines()
    
    # Filter out lines that start with '#'
    lines = [line for line in lines if not line.strip().startswith('%')]
    
    # Check if there are enough lines to process
    if len(lines) > 1:
        # Remove the first line
        lines = lines[1:]
        
        # Append the last line as a new line
        last_line = lines[-1]
        lines.append(last_line)
    
    # Write the modified content to the new file
    with open(new_file, 'w') as f:
        f.writelines(lines)

# Example usage



d_list=[3,5,7]
p_list=[0.001,0.001414,0.002,0.002828,0.004,0.005656,0.008,0.011312,0.016,0.022624,0.032,0.045249,0.064,0.090496,0.128,0.181,0.256,0.362]

for d in d_list:
	for p in p_list:
		ori_file=f'rot_surf_Hx_d{d}_trans_p{p}P.mmx'
		new_file=f'rot_surf_Hx_d{d}_trans_p{p}P'
		os.system("rm {new_file}")
		modify_file_ignore_comments(ori_file, new_file)

