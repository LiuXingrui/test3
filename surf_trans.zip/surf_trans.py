import os


d_list=[3,5,7]
p_list=[0.001,0.001414,0.002,0.002828,0.004,0.005656,0.008,0.011312,0.016,0.022624,0.032,0.045249,0.064,0.090496,0.128,0.181,0.256,0.362]


for d in d_list:
	for p in p_list:
		Hx=f'rot_surf_Hx_d{d}.mtx'
		Hz=f'rot_surf_Hz_d{d}.mtx'
		tempout=Hx+f'{p}'+'_temp'
		out=f'rot_surf_Hx_d{d}_trans_p{p}'
		command=f'./vecdec_2409 mode=2 finH={Hx} steps=10000 maxW=3 useP={p} outC={tempout}'
		os.system(command)
		command=f'./vecdec_2409 mode=3.32 finC={tempout} fout={out} finH={Hx} finG={Hz} useP={p}'
		os.system(command)

