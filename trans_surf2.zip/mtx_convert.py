import os


d_list=[3,5,7]
p_list=[0.001,0.001414,0.002,0.002828,0.004,0.005656,0.008,0.011312,0.016,0.022624,0.032,0.045249,0.064,0.090496,0.128,0.181,0.256,0.362]


for d in d_list:
	Hxmtx=f'rot_surf_Hx_d{d}_transH.mmx'
	Hzmtx=f'rot_surf_Hx_d{d}_transL.mmx'
	Hx=f'rot_surf_Hx_d{d}_transH'
	Hz=f'rot_surf_Hx_d{d}_transL'
	os.system(f"./conv2.out ./{Hxmtx}  ./{Hx}")
	os.system(f"./conv2.out ./{Hzmtx} ./{Hz}")




