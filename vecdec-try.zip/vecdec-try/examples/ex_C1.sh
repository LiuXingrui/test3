#
./src/vecdec mode=0 steps=1000 seed=7 \
	     finH=input/QX40.mtx finG=input/QZ40.mtx useP=0.02 \
	     nvec=1000 ntot=1000 
