#
./src/vecdec fdem= input/rep_code3.dem gdet=tmpA.01 gobs=tmpB.01 ntot=1500 nvec=1000 steps=0 mulP=2 uW=-1
