#
src/vecdec seed=7 mode=2 dW=0 finH= examples/204.33.484.alist useP=0.01 steps=10000
