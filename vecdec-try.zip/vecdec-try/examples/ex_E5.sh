#
./src/vecdec mode=3.64 finH=tmpH.mmx finL=tmpL.mmx finP=tmpP.mmx mulP=2 fout=try
