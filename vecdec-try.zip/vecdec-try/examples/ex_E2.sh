#
./src/vecdec mode=2 finH=tmpH.mmx useP=0.01 outC=tmp.nz steps=10000 dW=0

