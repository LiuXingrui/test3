#
./src/vecdec mode=3 fdem=./examples/surf_d3.dem fout=tmp 
