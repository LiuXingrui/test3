#
./src/vecdec debug=1 mode=1 maxosd=50 steps=10 lerr=1 \
	     finH= ./examples/96.3.963.alist ntot=1000 nvec=1000 useP=0.05 seed=113
