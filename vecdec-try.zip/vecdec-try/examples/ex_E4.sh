#
./src/vecdec mode=3.3 fdem=./examples/surf_d3.dem  finC=tmp.nz maxW=3 fout=tmp
