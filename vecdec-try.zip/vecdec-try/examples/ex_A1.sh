# ex_A1.sh
./src/vecdec seed=7 steps=5000 \
	     finH= ./examples/96.3.963.alist useP=0.05 \
	     ntot=1000 nvec=1000
