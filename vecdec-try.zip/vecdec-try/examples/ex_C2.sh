#
./src/vecdec mode=1.14 steps=10 lerr=2 seed=7 \
	     finH=input/QX40.mtx finG=input/QZ40.mtx useP=0.02 \
	     nvec=1000 ntot=1000 
